package patterns.strategy;

public interface PaymentStrategy {
    boolean pay(double amount);
}
