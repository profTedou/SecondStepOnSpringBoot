package patterns.observer;
public interface Observer {
    void update(String message);
}
