package com.gestionTiers.demo.model;

/*
Le package Model contient tous les classes metiers avec tous les Setters et les Getters
C'est ici qu'on définit toutes les tables de notre BD garce à l'annotattion @Entity
A l'instar de cette classe qui sera une table de la BD
 */


/*
Lombok est une bibliothèque qui permet de generer automatiquement les Setter et les Getter
ainsi que les constructeurs soit en AllArgsConstructor ou en NoARgConstructor
 */

/*
Les annotations sont des outils qui permettent d'effectuer des actions sur des données à l'instar de ID
et de GeneratedValue pour les attributs de clés primaires
 */
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name  = "PRODUIT")
@Getter
@Setter
@NoArgsConstructor
public class Produit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    public Produit(long id, String nom, String description) {
        this.id = id;
        this.nom = nom;
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public long getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setId(long id) {
        this.id = id;
    }

    private String nom;
    private String description;
}
