package com.gestionTiers.demo.service;

import com.gestionTiers.demo.model.Produit;

import java.util.List;

/*
ProduitService est une interface qui définit de facon concrète comment seront traitées et filtrées
Nous on fait ici un CRUD simple d'où les actions
Creer
Lire
Modifier
Supprimer
 */

public interface ProduitService {

    Produit creer(Produit produit);

    List<Produit> lire();

    Produit modifier(Long id, Produit produit);

    String supprimer(Long id);
}
