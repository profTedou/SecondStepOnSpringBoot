package com.gestionTiers.demo.service;

import com.gestionTiers.demo.model.Produit;
import com.gestionTiers.demo.repository.ProduitRepository;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/*
ProduitServiceImpl est une classe qui implemente ProsuitService c'est à dire définit de façon concrète
les méthodes des classes metiers

A noter ici que l'annotation @Service est utilisée pour que le JDK dans sonn execution le percoive comme
service et lui autorise l'accès au m"thode spécifique
 */
@Service
//@AllArgsConstructor
public class ProduitServiceImpl implements ProduitService{
/*
l'attribut de produitREpository permettent de faire le lien avec la BD et d'y effectuer
des manipulations
 */
    private final ProduitRepository produitRepository;

    public ProduitServiceImpl(ProduitRepository produitRepository) {
        this.produitRepository = produitRepository;
    }

    @Override
    public Produit creer(Produit produit) {
        return produitRepository.save(produit);
    }

    @Override
    public List<Produit> lire() {
        return produitRepository.findAll();
    }

    @Override
    public Produit modifier(Long id, Produit produit) {
        return produitRepository.findById(id)
                .map(p-> {
                    p.setNom(produit.getNom());
                    p.setDescription(produit.getDescription());
                    return produitRepository.save(p);
                }).orElseThrow(() -> new RuntimeException("produit non trouvé"));
    }

    @Override
    public String supprimer(Long id) {
        produitRepository.deleteById(id);
        return "Produit supprimé";
    }

}
