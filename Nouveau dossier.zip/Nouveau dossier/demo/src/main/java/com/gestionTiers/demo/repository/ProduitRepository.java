package com.gestionTiers.demo.repository;

import com.gestionTiers.demo.model.Produit;
import org.springframework.data.jpa.repository.JpaRepository;


/*
LA classe ProduitService est l'interface qui permet la persistance des données et sert
de lien avec les objets de la BD
 */

/*
C'est une interface qui etend JpaRepository et prends en param le format de la table et le format
de sa clé primaire
 */

/*
En somme il permet le mapage entre la BD et la classe metier Produit
 */

/*
Remarquons que l'annotation @Repository n'est pas utilisée car non necessaire du fait JpaRepository
qui est etendue le permet
 */
public interface ProduitRepository  extends JpaRepository<Produit,Long> {
}
