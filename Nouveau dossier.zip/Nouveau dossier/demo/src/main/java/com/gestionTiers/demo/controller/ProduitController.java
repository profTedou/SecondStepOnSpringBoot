package com.gestionTiers.demo.controller;

import com.gestionTiers.demo.model.Produit;
import com.gestionTiers.demo.service.ProduitService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

//expose les produits sur le reseau

/*
En effet coté client il faut recevoir les requêtes et les transmettre au Repository
D'où toute la beauté de l'APIRest
 */

/*
Ainsi seront utilisées les annotations ResController ET RequestMapping d'une part pour
recpnnaitre cette classe comme controller et permettre à cette classe de manager/gerer
les requetes et d'autre part pour mapper les requetes vers une table en particulier via
les end-points spécifiques preciser près de l'annotation
 */

/*
Remarque faite un objet produitService est instanciée et utilisée pour poser les actions sur
les donnees prévues dans la classe Service où elles y sont encapsulées
 */

/*
Expliquons les annotations
@PostMapping @GetMapping @PutMapping @DeleteMapping : reference le type de requête http vers
une méthode en particulier qu'on mappera avec un service en particulier
("/....") : définit de façon précise les endpoints qui va correspoondre à l'appel de la requête
@PathVariable @RequestBody : définissent la partie de requête qui contiendra les données
 */
@RestController
@RequestMapping("/produit")
//@AllArgsConstructor
public class ProduitController {
    private final ProduitService produitService;

    public ProduitController(ProduitService produitService) {
        this.produitService = produitService;
    }

    @PostMapping("/create")
    public Produit create(@RequestBody Produit produit){
        return produitService.creer(produit);
    }

    @GetMapping("/read")
    public List<Produit> read(){
        return produitService.lire();
    }

    @PutMapping("/update/{id}")
    public Produit update(@PathVariable Long id,@RequestBody Produit produit){
        return produitService.modifier(id, produit);
    }

    @DeleteMapping("/delete/{id}")
    public String delete(@PathVariable Long id){
        return produitService.supprimer(id);
    }
}
